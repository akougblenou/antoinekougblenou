<!DOCTYPE>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html>
<!-- Everything else goes in here -->
	<head>
		<style type="text/css"> 
			body{
				background-color: #000;
			}
			.container{ 
				margin:170px auto;
				width:940px;
			}
			img{
				margin: 0px auto;
			}
			img{
				display: block;
			}
		</style>
		<link rel="icon"  type="image/png"  href="favicon.png" />
		<title>Home</title>
	</head>
	<body>
			<!-- using div instead of section for the moment as the definition is not clear yet -->
		<div class="container">
			<img src="holding-page.png" alt="Site Coming Soon" />
		</div>

	</body>
<!-- Ending with the closing tag: -->
</html>